from flask import Flask, request, render_template, redirect, session, make_response, url_for
import sqlite3
import os
import time

app = Flask(__name__)
app.secret_key = "dev-secret-key-not-for-prod"  # noqa (intentional, practice app)

BASE = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE, "app.db")
UPLOAD_DIR = os.path.join(BASE, "static", "uploads")


@app.context_processor
def inject_session_info():
    return {"user_id": session.get("user_id"), "user": session.get("username")}


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


DESTINATIONS = [
    {"id": 1, "slug": "kyoto", "name": "Kyoto, Japan", "image": "dest_kyoto.jpg",
     "tagline": "Temples, tea houses & maple leaves",
     "description": ("Kyoto rewards slow travel. Spend mornings in the quiet gravel courtyards of "
                      "Zen temples before the crowds arrive, then wander Gion's lantern-lit lanes at dusk. "
                      "Don't miss the bamboo grove in Arashiyama at sunrise.")},
    {"id": 2, "slug": "santorini", "name": "Santorini, Greece", "image": "dest_santorini.jpg",
     "tagline": "Whitewashed cliffs over the Aegean",
     "description": ("The caldera views from Oia are famous for a reason, but the black-sand beaches "
                      "of Perissa and the ancient site of Akrotiri are worth the detour away from the crowds.")},
    {"id": 3, "slug": "patagonia", "name": "Patagonia, Chile", "image": "dest_patagonia.jpg",
     "tagline": "Glacial lakes & granite peaks",
     "description": ("Torres del Paine's W trek is demanding but the payoff — turquoise lakes under "
                      "jagged granite towers — is unlike anywhere else on earth.")},
    {"id": 4, "slug": "marrakech", "name": "Marrakech, Morocco", "image": "dest_marrakech.jpg",
     "tagline": "Spice souks & desert sunsets",
     "description": ("Get lost in the medina's souks, then escape the city heat with a night in the "
                      "Agafay desert, just 40 minutes from downtown.")},
    {"id": 5, "slug": "reykjavik", "name": "Reykjavik, Iceland", "image": "dest_reykjavik.jpg",
     "tagline": "Northern lights & lava fields",
     "description": ("Base yourself in Reykjavik and day-trip the Golden Circle, then chase the aurora "
                      "on clear nights between September and March.")},
    {"id": 6, "slug": "bali", "name": "Ubud, Bali", "image": "dest_bali.jpg",
     "tagline": "Rice terraces & jungle temples",
     "description": ("Ubud's Tegalalang rice terraces are postcard-famous, but the quieter Jatiluwih "
                      "terraces an hour north are just as stunning with a fraction of the visitors.")},
]


def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        email TEXT,
        bio TEXT,
        avatar TEXT DEFAULT 'default_avatar.png',
        is_admin INTEGER DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        destination_id INTEGER,
        username TEXT,
        rating INTEGER,
        body TEXT,
        created_at TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        body TEXT,
        created_at TEXT
    )""")
    c.execute("SELECT COUNT(*) as cnt FROM users")
    if c.fetchone()["cnt"] == 0:
        c.execute("INSERT INTO users (username,password,email,bio,is_admin) VALUES (?,?,?,?,?)",
                   ("maya", "maya travels 22", "maya@example.com", "Chasing shoulder-season flight deals.", 0))
        c.execute("INSERT INTO users (username,password,email,bio,is_admin) VALUES (?,?,?,?,?)",
                   ("theo", "theo hikes fast", "theo@example.com", "Slow travel, fast hikes.", 0))
        c.execute("INSERT INTO users (username,password,email,bio,is_admin) VALUES (?,?,?,?,?)",
                   ("admin", "TrailAdmin!2024Secure", "admin@trailtales.example", "Site administrator.", 1))
    c.execute("SELECT COUNT(*) as cnt FROM reviews")
    if c.fetchone()["cnt"] == 0:
        sample_reviews = [
            (1, "maya", 5, "Arashiyama at 6am was silent and misty, completely worth the early alarm.", "2026-03-11"),
            (1, "theo", 4, "Book the temple gardens in advance in cherry blossom season, they cap entries.", "2026-04-02"),
            (2, "maya", 5, "Watched the sunset from Oia and it genuinely lived up to the hype.", "2026-05-20"),
            (3, "theo", 5, "Bring layers, the wind off the glacier is brutal even in summer.", "2026-01-15"),
            (4, "maya", 4, "The desert camp guides were fantastic, book a small-group tour not a bus tour.", "2026-02-08"),
            (5, "theo", 5, "Saw the aurora on our second night, app alerts for solar activity really help.", "2026-11-30"),
        ]
        c.executemany("INSERT INTO reviews (destination_id, username, rating, body, created_at) VALUES (?,?,?,?,?)",
                       sample_reviews)
    c.execute("SELECT COUNT(*) as cnt FROM notes")
    if c.fetchone()["cnt"] == 0:
        c.execute("INSERT INTO notes (user_id, title, body, created_at) VALUES (?,?,?,?)",
                   (1, "Packing list — Iceland trip", "Thermal layers, waterproof boots, spare SD cards. Passport expiry: check before booking flights.", "2026-09-01"))
        c.execute("INSERT INTO notes (user_id, title, body, created_at) VALUES (?,?,?,?)",
                   (2, "Budget notes — Morocco", "Riad deposit paid via bank transfer, confirmation number kept in email. Remaining budget: keep track separately.", "2026-08-14"))
    conn.commit()
    conn.close()


@app.route("/")
def home():
    return render_template("index.html", destinations=DESTINATIONS)


@app.route("/destination/<slug>")
def destination(slug):
    dest = next((d for d in DESTINATIONS if d["slug"] == slug), None)
    if not dest:
        return "Destination not found", 404
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM reviews WHERE destination_id = ? ORDER BY id DESC", (dest["id"],))
    reviews = c.fetchall()
    conn.close()
    return render_template("destination.html", dest=dest, reviews=reviews)


@app.route("/destination/<slug>/review", methods=["POST"])
def add_review(slug):
    dest = next((d for d in DESTINATIONS if d["slug"] == slug), None)
    if not dest:
        return "Destination not found", 404
    if "username" not in session:
        return redirect("/login")
    body = request.form.get("body", "")
    rating = request.form.get("rating", "5")
    conn = get_db()
    c = conn.cursor()
    c.execute("INSERT INTO reviews (destination_id, username, rating, body, created_at) VALUES (?,?,?,?,?)",
              (dest["id"], session["username"], rating, body, time.strftime("%Y-%m-%d")))
    conn.commit()
    conn.close()
    return redirect(url_for("destination", slug=slug))


@app.route("/search")
def search():
    q = request.args.get("q", "")
    results = []
    if q:
        ql = q.lower()
        results = [d for d in DESTINATIONS if ql in d["name"].lower() or ql in d["tagline"].lower()]
    return render_template("search.html", query=q, results=results)


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        conn = get_db()
        c = conn.cursor()
        query = "SELECT * FROM users WHERE username = '{}' AND password = '{}'".format(username, password)
        c.execute(query)
        row = c.fetchone()
        conn.close()
        if row:
            session["username"] = row["username"]
            session["user_id"] = row["id"]
            session["is_admin"] = bool(row["is_admin"])
            return redirect("/")
        error = "Invalid username or password."
    return render_template("login.html", error=error)


@app.route("/register", methods=["GET", "POST"])
def register():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        email = request.form.get("email", "")
        conn = get_db()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (username,password,email,bio) VALUES (?,?,?,?)",
                      (username, password, email, ""))
            conn.commit()
            conn.close()
            return redirect("/login")
        except sqlite3.IntegrityError:
            error = "That username is taken."
            conn.close()
    return render_template("register.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


@app.route("/notes")
def notes_list():
    if "user_id" not in session:
        return redirect("/login")
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM notes WHERE user_id = ? ORDER BY id DESC", (session["user_id"],))
    rows = c.fetchall()
    conn.close()
    return render_template("notes.html", notes=rows)


@app.route("/notes/new", methods=["POST"])
def notes_new():
    if "user_id" not in session:
        return redirect("/login")
    title = request.form.get("title", "Untitled note")
    body = request.form.get("body", "")
    conn = get_db()
    c = conn.cursor()
    c.execute("INSERT INTO notes (user_id, title, body, created_at) VALUES (?,?,?,?)",
              (session["user_id"], title, body, time.strftime("%Y-%m-%d")))
    conn.commit()
    conn.close()
    return redirect("/notes")


@app.route("/notes/<int:note_id>")
def note_detail(note_id):
    if "user_id" not in session:
        return redirect("/login")
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM notes WHERE id = ?", (note_id,))
    note = c.fetchone()
    conn.close()
    if not note:
        return "Note not found", 404
    return render_template("note_detail.html", note=note)


@app.route("/profile", methods=["GET", "POST"])
def profile():
    if "user_id" not in session:
        return redirect("/login")
    conn = get_db()
    c = conn.cursor()
    if request.method == "POST":
        bio = request.form.get("bio", "")
        c.execute("UPDATE users SET bio = ? WHERE id = ?", (bio, session["user_id"]))
        conn.commit()
    c.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],))
    u = c.fetchone()
    conn.close()
    return render_template("profile.html", profile=u)


@app.route("/profile/avatar", methods=["POST"])
def upload_avatar():
    if "user_id" not in session:
        return redirect("/login")
    file = request.files.get("avatar")
    if file and file.filename:
        filename = file.filename  # note: not sanitized
        save_path = os.path.join(UPLOAD_DIR, filename)
        file.save(save_path)
        conn = get_db()
        c = conn.cursor()
        c.execute("UPDATE users SET avatar = ? WHERE id = ?", ("uploads/" + filename, session["user_id"]))
        conn.commit()
        conn.close()
    return redirect("/profile")


@app.route("/go")
def go():
    target = request.args.get("to", "/")
    return redirect(target)


@app.route("/admin")
def admin():
    if not session.get("is_admin"):
        return "Forbidden: admins only.", 403
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users")
    users = c.fetchall()
    conn.close()
    return render_template("admin.html", users=users)


@app.route("/robots.txt")
def robots():
    resp = make_response(
        "User-agent: *\nDisallow: /admin\nDisallow: /exports/\nDisallow: /internal-notes\n"
    )
    resp.headers["Content-Type"] = "text/plain"
    return resp


@app.route("/exports/trailtales-users-export.csv.txt")
def fake_export():
    resp = make_response(
        "id,username,email,note\n"
        "1,maya,maya@example.com,ok\n"
        "2,theo,theo@example.com,ok\n"
        "3,admin,admin@trailtales.example,pwd=TrailAdmin!2024Secure - rotate before launch\n"
    )
    resp.headers["Content-Type"] = "text/plain"
    return resp


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
