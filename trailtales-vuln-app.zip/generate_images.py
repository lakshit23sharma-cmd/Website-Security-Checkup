from PIL import Image, ImageDraw, ImageFont
import random
import os

OUT = os.path.join(os.path.dirname(__file__), "static", "images")
os.makedirs(OUT, exist_ok=True)

def get_font(size):
    try:
        return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", size)
    except Exception:
        return ImageFont.load_default()

def gradient(size, c1, c2, vertical=True):
    w, h = size
    img = Image.new("RGB", size, c1)
    top = Image.new("RGB", size, c2)
    mask = Image.new("L", size)
    mdata = []
    for y in range(h):
        for x in range(w):
            v = y / h if vertical else x / w
            mdata.append(int(255 * v))
    mask.putdata(mdata)
    img.paste(top, (0, 0), mask)
    return img

def make_card(filename, label, subtitle, c1, c2, w=640, h=420):
    img = gradient((w, h), c1, c2)
    draw = ImageDraw.Draw(img, "RGBA")
    # a few soft translucent shapes for texture
    for _ in range(6):
        x0 = random.randint(-50, w)
        y0 = random.randint(-50, h)
        r = random.randint(60, 180)
        draw.ellipse([x0, y0, x0 + r, y0 + r], fill=(255, 255, 255, 25))
    # bottom gradient bar for text legibility
    overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    odraw = ImageDraw.Draw(overlay)
    odraw.rectangle([0, h - 130, w, h], fill=(20, 20, 20, 140))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    draw = ImageDraw.Draw(img)
    font_big = get_font(34)
    font_small = get_font(18)
    draw.text((24, h - 108), label, font=font_big, fill=(255, 255, 255))
    draw.text((24, h - 60), subtitle, font=font_small, fill=(230, 230, 230))
    img.save(os.path.join(OUT, filename), quality=88)

destinations = [
    ("dest_kyoto.jpg", "Kyoto, Japan", "Temples, tea houses & maple leaves", (60, 90, 70), (150, 190, 130)),
    ("dest_santorini.jpg", "Santorini, Greece", "Whitewashed cliffs over the Aegean", (40, 80, 140), (140, 190, 230)),
    ("dest_patagonia.jpg", "Patagonia, Chile", "Glacial lakes & granite peaks", (30, 50, 60), (90, 130, 140)),
    ("dest_marrakech.jpg", "Marrakech, Morocco", "Spice souks & desert sunsets", (150, 70, 30), (230, 150, 60)),
    ("dest_reykjavik.jpg", "Reykjavik, Iceland", "Northern lights & lava fields", (25, 30, 60), (80, 100, 160)),
    ("dest_bali.jpg", "Ubud, Bali", "Rice terraces & jungle temples", (30, 90, 60), (110, 180, 110)),
]

for fname, label, sub, c1, c2 in destinations:
    make_card(fname, label, sub, c1, c2)

# default avatar
def make_avatar(filename, initials, c1, c2):
    size = (200, 200)
    img = gradient(size, c1, c2)
    draw = ImageDraw.Draw(img)
    font = get_font(64)
    bbox = draw.textbbox((0, 0), initials, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text(((200 - tw) / 2, (200 - th) / 2 - 8), initials, font=font, fill=(255, 255, 255))
    img.save(os.path.join(OUT, filename))

make_avatar("default_avatar.png", "?", (100, 100, 110), (60, 60, 70))

# a small hero banner
hero = gradient((1200, 320), (35, 55, 90), (110, 150, 190))
hd = ImageDraw.Draw(hero, "RGBA")
for _ in range(10):
    x0 = random.randint(-80, 1200)
    y0 = random.randint(-80, 320)
    r = random.randint(80, 240)
    hd.ellipse([x0, y0, x0 + r, y0 + r], fill=(255, 255, 255, 18))
hero.save(os.path.join(OUT, "hero.jpg"), quality=88)

print("Generated", len(destinations) + 2, "images")
