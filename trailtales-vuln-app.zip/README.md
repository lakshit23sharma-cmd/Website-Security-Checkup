# TrailTales — Practice Web Security Target

A travel-journal style website (destinations, photos, reviews, private notes,
profile with avatar upload) built for practicing vulnerability discovery.
It ships with an intermediate-level set of intentionally planted security flaws.

## Setup

```bash
pip install flask pillow
python3 generate_images.py   # only needed if static/images is empty
python3 app.py
```

Then open http://127.0.0.1:5000

Accounts are seeded automatically in `app.db` (SQLite) on first run. You
don't need to know them to complete the exercise — they just give the site
some starting data (destinations, sample reviews, sample notes).

## Rules of the exercise

- Only test this app on your own machine, against this local instance.
- Explore everything reachable from the UI: nav bar, footer, search box,
  review forms, notes, and the avatar upload.
- Try unexpected input, tampered URLs/IDs, unusual file uploads, and check
  for files/pages that aren't linked from the UI at all.
